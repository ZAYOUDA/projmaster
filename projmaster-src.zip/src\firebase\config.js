import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore, enableIndexedDbPersistence } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);

// Base Firestore ciblée : VITE_FIRESTORE_DB_ID sépare dev/preview local (base vide)
// de la prod (base réelle) — voir .env.local vs .env.deploy.local.
const dbId = import.meta.env.VITE_FIRESTORE_DB_ID || 'default';
export const db = dbId === '(default)' ? getFirestore(app) : getFirestore(app, dbId);

// Offline persistence (sync auto au retour en ligne)
enableIndexedDbPersistence(db).catch(() => {});
